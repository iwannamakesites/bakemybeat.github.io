
let selectedArtists = [];
let treats = ["Cupcake", "Macaron", "Latte", "Brownie", "Boba Tea", "Donut", "Strawberry Tart"];
let artistInput = document.getElementById("artist-input");
let artistList = document.getElementById("artist-list");

function addArtist() {
  let name = artistInput.value.trim();
  if (name && selectedArtists.length < 5 && !selectedArtists.includes(name)) {
    selectedArtists.push(name);
    let li = document.createElement("li");
    li.textContent = name;
    artistList.appendChild(li);
    artistInput.value = "";
    if (selectedArtists.length === 5) generateBakery();
  }
}

function generateBakery() {
  document.getElementById("artist-pick").classList.add("hidden");
  document.getElementById("bakery").classList.remove("hidden");

  let menuDiv = document.getElementById("menu");
  treats.forEach(treat => {
    let div = document.createElement("div");
    div.className = "menu-item";
    div.textContent = treat;
    div.draggable = true;
    div.addEventListener("dragstart", e => {
      e.dataTransfer.setData("text", treat);
    });
    menuDiv.appendChild(div);
  });

  let display = document.getElementById("display-window");
  display.addEventListener("dragover", e => e.preventDefault());
  display.addEventListener("drop", e => {
    e.preventDefault();
    let treat = e.dataTransfer.getData("text");
    let item = document.createElement("div");
    item.className = "display-item";
    item.textContent = treat;
    display.appendChild(item);
  });
}

function openShop() {
  document.getElementById("bakery").classList.add("hidden");
  document.getElementById("customers").classList.remove("hidden");

  let ordersDiv = document.getElementById("customer-orders");
  selectedArtists.forEach(artist => {
    let order = document.createElement("div");
    order.className = "order";
    let treat = treats[Math.floor(Math.random() * treats.length)];
    order.textContent = artist + " wants a " + treat + "!";
    ordersDiv.appendChild(order);
  });
}
